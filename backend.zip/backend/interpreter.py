"""
AI Interpreter using Google Gemini API.
Enhanced version with structured JSON output and domain knowledge.
"""

import os
import json
from typing import List, Dict, Optional, Any
from collections import Counter
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

try:
    from google import genai
except ImportError:
    genai = None


class GeminiInterpreter:
    """AI interpreter for cluster analysis using Gemini API."""

    # Domain knowledge for HPC systems
    DOMAIN_KNOWLEDGE = """
## HPC System Domain Knowledge

### Temperature Variables
- AirIn: Inlet air temperature to the compute racks (from room cooling)
- AirOut: Outlet air temperature from the compute racks (exhaust heat)
- Water: Cooling water temperature supplied to CPUs inside compute racks
- CPU: CPU temperature sensor reading

### Facility Layout
- The compute room contains 864 racks arranged in 24 columns (A-X) × 36 rows
- Storage racks are placed between specific pairs of compute rack rows: (2,3), (6,7), (10,11), (14,15), (18,19), (22,23), (26,27), (30,31), (34,35)

### Thermal Interactions
- Storage racks generate additional heat, which can raise AirIn for compute racks located near the storage rack row boundaries
- Spatial heat bands or localized hot spots with elevated AirIn can form inside the compute room
- Higher AirIn directly increases AirOut (they are coupled)
- Memory-intensive workloads increase heat removal demand for air-cooled memory, raising AirOut
- Energy-intensive workloads increase heat from air-cooled power supply units (PSUs), also raising AirOut

### Sensor Characteristics
- Some Water sensors are mounted on the outside of water piping, so their readings can be biased by surrounding ambient air temperature, especially in rack rows with higher AirIn

### Workload Effects
- High CPU workload raises CPU temperature
- High initial Water temperature raises CPU temperature
"""

    def __init__(self, api_key: Optional[str] = None):
        api_key = "AIzaSyB2a8F06fK9pfWURhg7kQF1FT8UcfnQF4Q"
        if genai and api_key:
            self.client = genai.Client(api_key=api_key)
            print("Gemini API client initialized.") 
        else:
            print("Gemini API client not initialized.")
            self.client = None

    def interpret(
        self,
        top_features: List[Dict],
        cluster1_size: int,
        cluster2_size: int
    ) -> Dict[str, Any]:
        """Generate structured interpretation of cluster differences."""
        if not self.client or not top_features:
            return self._fallback_interpretation(top_features)

        # Preprocess data for better context
        preprocessed = self._preprocess_features(top_features)

        prompt = self._build_prompt(
            top_features=top_features,
            cluster1_size=cluster1_size,
            cluster2_size=cluster2_size,
            preprocessed=preprocessed
        )

        try:
            response = self.client.models.generate_content(
                model='gemini-2.5-flash',
                contents=prompt
            )
            return self._parse_json_response(response.text, top_features)
        except Exception as e:
            print(f"API error: {e}")
            return self._fallback_interpretation(top_features)

    def _preprocess_features(self, features: List[Dict]) -> Dict[str, Any]:
        """Preprocess features to extract patterns."""
        # Variable distribution
        variables = [f.get('variable', '') for f in features]
        variable_counts = dict(Counter(variables))

        # Rack distribution
        racks = [f.get('rack', '') for f in features]
        rack_rows = [r[1:] if len(r) > 1 else '' for r in racks]  # Extract row numbers
        rack_cols = [r[0] if r else '' for r in racks]  # Extract column letters

        # Significant features
        significant = [
            f for f in features
            if f.get('statistical_result', {}).get('p_value', 1.0) < 0.05
        ]

        # Co-occurrence analysis (same rack, multiple variables)
        rack_variables = {}
        for f in features:
            rack = f.get('rack', '')
            var = f.get('variable', '')
            if rack not in rack_variables:
                rack_variables[rack] = []
            rack_variables[rack].append(var)

        co_occurrences = []
        for rack, vars in rack_variables.items():
            if len(vars) > 1:
                co_occurrences.append({
                    'rack': rack,
                    'variables': vars
                })

        # Effect size summary
        effect_sizes = [
            f.get('statistical_result', {}).get('cohen_d', 0)
            for f in features
        ]
        avg_effect = sum(effect_sizes) / len(effect_sizes) if effect_sizes else 0

        return {
            'variable_distribution': variable_counts,
            'significant_count': len(significant),
            'total_count': len(features),
            'co_occurrences': co_occurrences,
            'avg_effect_size': round(avg_effect, 3),
            'dominant_variable': max(variable_counts, key=variable_counts.get) if variable_counts else None,
            'rack_concentration': self._analyze_spatial_pattern(racks)
        }

    def _analyze_spatial_pattern(self, racks: List[str]) -> str:
        """Analyze if racks are spatially concentrated or distributed."""
        if not racks:
            return "unknown"

        cols = [r[0] for r in racks if r]
        rows = [int(r[1:]) for r in racks if len(r) > 1 and r[1:].isdigit()]

        if not cols or not rows:
            return "unknown"

        col_spread = len(set(cols))
        row_spread = max(rows) - min(rows) if rows else 0

        if col_spread <= 5 and row_spread <= 10:
            return "concentrated"
        elif col_spread >= 15 or row_spread >= 25:
            return "widely distributed"
        else:
            return "moderately distributed"

    def _build_prompt(
        self,
        top_features: List[Dict],
        cluster1_size: int,
        cluster2_size: int,
        preprocessed: Dict[str, Any]
    ) -> str:
        """Build the prompt for LLM."""
        features_text = self._format_features(top_features[:30])

        return f"""
You are an AI assistant that generates structured summaries of HPC cluster analysis results.
Your role is to organize and describe the data clearly - NOT to make causal claims or predictions.

{self.DOMAIN_KNOWLEDGE}

## Analysis Context
- Red Cluster (Cluster 1): {cluster1_size} time points
- Blue Cluster (Cluster 2): {cluster2_size} time points

## Preprocessed Statistics
- Significant features: {preprocessed['significant_count']}/{preprocessed['total_count']}
- Dominant variable type: {preprocessed['dominant_variable']}
- Variable distribution: {preprocessed['variable_distribution']}
- Average effect size: {preprocessed['avg_effect_size']}
- Spatial pattern: {preprocessed['rack_concentration']}
- Co-occurring variables in same rack: {len(preprocessed['co_occurrences'])} cases

## Top Features (up to 30, by contribution score)
{features_text}

## Output Instructions
Generate a JSON response with the following structure. Each section should contain natural language text (2-3 sentences) in ENGLISH for academic publication.
Do NOT use any special formatting like brackets or markdown. Write in plain text.

{{
  "sections": [
    {{
      "title": "Key Findings",
      "text": "Describe the primary differences between clusters in 2-3 sentences. Mention specific rack-variable pairs (e.g., M15-CPU).",
      "highlights": []
    }},
    {{
      "title": "Pattern Analysis",
      "text": "Describe variable type distribution and spatial patterns. Mention which variable types dominate.",
      "highlights": []
    }},
    {{
      "title": "Statistical Summary",
      "text": "Summarize statistical significance and effect sizes objectively with numbers.",
      "highlights": []
    }},
    {{
      "title": "Insights & Caveats",
      "text": "Suggest tentative hypotheses using cautious language (may indicate, suggests, could be related to). Note that correlation does not imply causation.",
      "highlights": []
    }}
  ]
}}

## Requirements
- Output ONLY valid JSON, no other text
- Text should be in ENGLISH (for academic publication)
- Each text field should be 2-3 sentences
- Be specific about rack names and variable types
- Reference cluster colors (Red Cluster / Blue Cluster) when describing differences
- For Insights: Use tentative language ("may indicate", "suggests", "could be")
- Do NOT use brackets, asterisks, or any special formatting - plain text only
"""

    def _format_features(self, features: List[Dict]) -> str:
        """Format features for prompt."""
        lines = []
        for i, f in enumerate(features, 1):
            stat = f.get('statistical_result', {})
            p_value = stat.get('p_value', 1.0)
            significance = "*" if p_value < 0.01 else ("+" if p_value < 0.05 else "")
            direction = "higher in C1" if f.get('mean_diff', 0) > 0 else "lower in C1"
            effect = stat.get('effect_size', 'N/A')
            
            lines.append(
                f"{i:2}. {f.get('rack', '?')}-{f.get('variable', '?')} ({direction}, "
                f"score:{f.get('score', 0):.3f}, p:{p_value:.4f}, effect:{effect}){significance}"
            )
        return '\n'.join(lines)

    def _parse_json_response(self, response_text: str, features: List[Dict]) -> Dict[str, Any]:
        """Parse JSON from LLM response."""
        try:
            # Try to extract JSON from response
            text = response_text.strip()
            
            # Handle markdown code blocks
            if text.startswith('```json'):
                text = text[7:]
            if text.startswith('```'):
                text = text[3:]
            if text.endswith('```'):
                text = text[:-3]
            
            text = text.strip()
            result = json.loads(text)
            
            # Validate structure
            if 'sections' not in result:
                return self._fallback_interpretation(features)
            
            return result
            
        except json.JSONDecodeError as e:
            print(f"JSON parse error: {e}")
            print(f"Response was: {response_text[:500]}")
            return self._fallback_interpretation(features)

    def _fallback_interpretation(self, features: List[Dict]) -> Dict[str, Any]:
        """Fallback interpretation when API is unavailable."""
        if not features:
            return {
                "sections": [
                    {
                        "title": "Error",
                        "text": "Analysis data is missing.",
                        "highlights": []
                    }
                ]
            }

        top = features[0]
        direction = 'higher' if top.get('mean_diff', 0) > 0 else 'lower'
        rack = top.get('rack', 'unknown')
        variable = top.get('variable', 'unknown')

        return {
            "sections": [
                {
                    "title": "Key Findings",
                    "text": f"The primary difference between clusters is [{rack}-{variable}]. Values are {direction} in the Red Cluster. Further statistical analysis is recommended.",
                    "highlights": [f"{rack}-{variable}"]
                },
                {
                    "title": "Insights & Caveats",
                    "text": "This is a fallback summary generated when AI API is unavailable.",
                    "highlights": []
                }
            ]
        }

    def compare_analyses(
        self,
        analysis_a: Dict[str, Any],
        analysis_b: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Compare two saved analyses using Gemini."""
        if not self.client:
            return self._fallback_comparison(analysis_a, analysis_b)

        # Check which clusters match between the two analyses
        same_cluster1 = analysis_a.get('cluster1_size') == analysis_b.get('cluster1_size')
        same_cluster2 = analysis_a.get('cluster2_size') == analysis_b.get('cluster2_size')
        
        # Determine comparison context
        if same_cluster1 and same_cluster2:
            context_msg = "Both analyses use IDENTICAL cluster selections. Any differences in results are due to analysis parameters."
        elif same_cluster1:
            context_msg = "Both analyses share the SAME Red Cluster (C1) as the base. The comparison involves different Blue Cluster (C2) selections."
        elif same_cluster2:
            context_msg = "Both analyses share the SAME Blue Cluster (C2) as the base. The comparison involves different Red Cluster (C1) selections."
        else:
            context_msg = "The analyses use completely different cluster selections."
        
        # Extract top features
        features_a = analysis_a.get('top_features', [])[:10]
        features_b = analysis_b.get('top_features', [])[:10]
        
        feature_set_a = set(f"{f.get('rack')}-{f.get('variable')}" for f in features_a)
        feature_set_b = set(f"{f.get('rack')}-{f.get('variable')}" for f in features_b)
        
        common = feature_set_a & feature_set_b
        only_a = feature_set_a - feature_set_b
        only_b = feature_set_b - feature_set_a

        prompt = f"""
You are an AI assistant analyzing the difference between two cluster analyses on HPC data.

{self.DOMAIN_KNOWLEDGE}

## Comparison Context
{context_msg}

## Analysis A
- Red Cluster (C1): {analysis_a.get('cluster1_size')} points
- Blue Cluster (C2): {analysis_a.get('cluster2_size')} points
- Significant features: {analysis_a.get('summary', {}).get('significant_count', 'N/A')}
- Top variables: {', '.join(analysis_a.get('summary', {}).get('top_variables', []))}

## Analysis B
- Red Cluster (C1): {analysis_b.get('cluster1_size')} points
- Blue Cluster (C2): {analysis_b.get('cluster2_size')} points
- Significant features: {analysis_b.get('summary', {}).get('significant_count', 'N/A')}
- Top variables: {', '.join(analysis_b.get('summary', {}).get('top_variables', []))}

## Cluster Matching
- Red Cluster (C1): {'SAME' if same_cluster1 else 'DIFFERENT'} ({analysis_a.get('cluster1_size')} vs {analysis_b.get('cluster1_size')} points)
- Blue Cluster (C2): {'SAME' if same_cluster2 else 'DIFFERENT'} ({analysis_a.get('cluster2_size')} vs {analysis_b.get('cluster2_size')} points)

## Feature Comparison
- Common features in both: {', '.join(common) if common else 'None'}
- Only in Analysis A: {', '.join(only_a) if only_a else 'None'}
- Only in Analysis B: {', '.join(only_b) if only_b else 'None'}

## Output Instructions
Generate a JSON response in ENGLISH for academic publication. Each section should be 2-3 sentences.
Do NOT use any special formatting - plain text only.

{{
  "sections": [
    {{
      "title": "Overview",
      "text": "State which clusters are the same and which are different between the two analyses. If sizes match, treat them as the same cluster selection.",
      "highlights": []
    }},
    {{
      "title": "Key Differences",
      "text": "Describe the main differences in feature importance. Which features appeared or disappeared? What might this suggest about the data?",
      "highlights": []
    }},
    {{
      "title": "Suggested Exploration",
      "text": "Recommend next steps based on the differences observed. What should the researcher investigate further?",
      "highlights": []
    }}
  ]
}}

## Requirements
- Output ONLY valid JSON, no other text
- Text should be in ENGLISH (for academic publication)
- Each section should be 2-3 sentences
- {"Mention that both analyses share the same base cluster" if same_cluster1 or same_cluster2 else "Note that different clusters are compared"}
- Do NOT use brackets, asterisks, arrows, or any special formatting - plain text only
"""

        try:
            response = self.client.models.generate_content(
                model='gemini-2.5-flash',
                contents=prompt
            )
            return self._parse_json_response(response.text, [])
        except Exception as e:
            print(f"Compare API error: {e}")
            return self._fallback_comparison(analysis_a, analysis_b)

    def _fallback_comparison(
        self, 
        analysis_a: Dict[str, Any], 
        analysis_b: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Fallback comparison when API is unavailable."""
        same_base = analysis_a.get('cluster1_size') == analysis_b.get('cluster1_size')
        
        return {
            "sections": [
                {
                    "title": "Overview",
                    "text": f"Comparing two analyses. {'Both use the same base cluster (Red Cluster).' if same_base else 'Different base clusters are being compared.'}",
                    "highlights": []
                },
                {
                    "title": "Note",
                    "text": "Detailed comparison analysis requires AI API. Currently running in fallback mode.",
                    "highlights": []
                }
            ]
        }

